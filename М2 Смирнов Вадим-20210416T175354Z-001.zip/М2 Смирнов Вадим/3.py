import hashlib
A = []
f=open('Task3-tx.txt')
for line in f:
    line=line.rstrip('\n')
    A.append(line)
if len(A)%2==0:
    print('Листьев -',len(A))
else:
    print('Листьев -',len(A)+1)
print('Hash  1 транзакции -',hashlib.sha256(A[0].encode()).hexdigest())

l=0
def tophash(u):
    global l

    t=[]
    if len(u)==1:
        l=l+1
        print('Уровней -',l)
        a=hashlib.sha3_384(u[0].encode()).hexdigest()
        print('Tophash -',a)
        breakpoint()


    if len(u)>1:
        l=l+1

        if len(u)%2!=0:
            u.append(u[len(u)-1])
        for i in range(0,len(u)):
            u[i]=hashlib.sha3_384(u[i].encode()).hexdigest()
        x=0
        while x<len(u):
            t.append(u[x]+u[x+1])
            x=x+2
        u.clear()
        for i in range(0,len(t)):
            u.append(t[i])

    tophash(u)

tophash(A)
