import json
import hashlib

with open('Task3_block.json') as file:
    file = json.loads(file.read())
    #file=str(file).replace("'",'"').replace(", ",',').replace(": ",':')



hash='111112'


while hash[0:2]!='00' and hash[-3:]!='111':
    res=hashlib.md5(str(file).replace("'",'"').replace(", ",',').replace(": ",':').encode()).hexdigest()
    hash=res
    file['nonce']+=1
print(file['nonce'])



