import hashlib

sl="JuniorSkills2021Final"

b=hashlib.sha256(sl.encode()).hexdigest()
c=0
for i in range(100000,1000000):
    h2=b+str(i)

    a=hashlib.sha384(h2.encode()).hexdigest()
    if a[0:2]=='01' and a[-2:]=='10':

        c=c+1

    a = hashlib.sha3_224(h2.encode()).hexdigest()
    if a[0:2] == '01' and a[-2:] == '10':

        c = c + 1
    a = hashlib.sha3_256(h2.encode()).hexdigest()
    if a[0:2] == '01' and a[-2:] == '10':

        c = c + 1
    a = hashlib.sha3_384(h2.encode()).hexdigest()
    if a[0:2] == '01' and a[-2:] == '10':

        c = c + 1

    a = hashlib.sha3_512(h2.encode()).hexdigest()
    if a[0:2] == '01' and a[-2:] == '10':



        c = c + 1

print(b)
print("sha3_512")

print('01abb5e63abe5522d6e00d2252d72d1863857fea4efbde2d78d05ee18006ce3281d1b41f68d8d72a3bf4313dd4e841f23fc7d8918235fda4e85cec7e0c977f10')

print(129006)
print(c)